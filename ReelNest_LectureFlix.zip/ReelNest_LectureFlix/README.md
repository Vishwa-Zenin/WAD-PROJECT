# ReelNest — LectureFlix Hack

A responsive academic lecture streaming and revision companion built with **HTML5, CSS3 and Vanilla JavaScript (ES6+)**.

## Run the project
1. Extract `ReelNest_LectureFlix.zip`.
2. Open the extracted folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code **Live Server** extension.
4. Internet access is required for Google Fonts, Font Awesome icons and the sample MP4 video.

No npm install or build step is required.

## Five visual themes
Use the **Theme** button in the top-right corner:
1. Ember — Red / Black (main presentation theme)
2. Ocean — Blue / Black
3. Violet — Purple / Midnight
4. Forest — Green / Charcoal
5. Sunset — Orange / Graphite

The selected theme is saved in LocalStorage.

## Features included
- Netflix-inspired lecture catalogue grouped by four departments (16 sample lectures).
- Featured hero banner with Watch Featured and Course Syllabus actions.
- Search by lecture title, topic, department, course code and professor.
- Department filters and horizontal scrolling lecture rows.
- Video player with play/pause, seek, volume handled by browser, skip ±5 seconds, fullscreen and playback speeds.
- Timestamped notes saved against the current lecture and clickable timestamps for seeking.
- One-click revision bookmarks with duplicate-nearby protection.
- Continue-watching history persisted in LocalStorage and restored on return.
- Searchable sample transcript with timestamp navigation.
- Picture-in-Picture support where browser permits.
- Keyboard shortcuts: Space (play/pause), Left/Right arrows (±5 sec), Escape (close), Ctrl/Cmd + K (search).
- Notes can be printed or saved as PDF using the **PDF** button in the notes panel; choose **Save as PDF** in the browser print dialog.
- Responsive desktop, tablet and mobile layout.

## Important demo note
The PDF brief asks for a registry of 16 university lectures with video URLs, professor bios and sample notes. This frontend includes 16 sample lecture records and sample transcript lines. To keep the project runnable without a backend/API key, the player currently uses one public sample MP4 for demonstration. Replace `VIDEO_URL` in `js/app.js` or the `<source>` in `index.html` with your own lecture video URLs for the final presentation.

## Tech concepts demonstrated
- Semantic HTML5 and responsive CSS Grid / Flexbox.
- Vanilla JavaScript ES6+, array methods, template literals, event delegation patterns, filtering and state management.
- Debounced-style live client filtering (input-driven; can be extended with a timer-based debounce).
- LocalStorage persistence for watch history, notes, bookmarks and theme.
- HTML5 Media API (`currentTime`, `duration`, `playbackRate`, `requestPictureInPicture`).
- Timestamp formatting and transcript time navigation.

## Suggested group presentation flow
1. Open the Ember red/black theme and introduce the ReelNest hero section.
2. Switch through all five themes.
3. Search for “Dijkstra” and open the lecture.
4. Play the sample video, save a note, and add a bookmark.
5. Click the timestamp to jump to the saved moment.
6. Close and reopen the lecture from Continue Watching to show progress persistence.
7. Open My Notes and My Bookmarks from the sidebar.
